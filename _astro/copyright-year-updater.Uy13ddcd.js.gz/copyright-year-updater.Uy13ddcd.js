const r=new Date,t=document.querySelectorAll(".copyright-year");t.forEach(e=>{e!==null&&(e.innerHTML=r.getFullYear().toString())});
