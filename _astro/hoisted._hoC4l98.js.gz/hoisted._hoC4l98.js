document.addEventListener("DOMContentLoaded",a=>{document.querySelectorAll(".image-wrapper").forEach(e=>{e.querySelectorAll("img").length>0&&e.classList.add("has-images")})});
